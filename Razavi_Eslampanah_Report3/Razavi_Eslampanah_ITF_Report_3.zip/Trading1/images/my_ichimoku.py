//@version=4
//src = input(hlc3)

donchian(len) => avg(lowest(len), highest(len))

ichimoku_function(inTradeWindow) =>
    
    conversionPeriods = input(9, minval=1, title="Conversion Line Periods"),
    basePeriods = input(26, minval=1, title="Base Line Periods")
    laggingSpan2Periods = input(52, minval=1, title="Lagging Span 2 Periods"),
    displacement = input(26, minval=0, title="Displacement")

    

    conversionLine = donchian(conversionPeriods)
    baseLine = donchian(basePeriods)
    leadLine1 = avg(conversionLine, baseLine)
    leadLine2 = donchian(laggingSpan2Periods)

    //plot(conversionLine, color=#0496ff, title="Conversion Line")
    //plot(baseLine, color=#991515, title="Base Line")
    //plot(close, offset = -displacement, color=#459915, title="Lagging Span")

    //p1 = plot(leadLine1, offset = displacement, color=color.green,
    //title="Lead 1")
    //p2 = plot(leadLine2, offset = displacement, color=color.red, 
    //title="Lead 2")
    //fill(p1, p2, color = leadLine1 > leadLine2 ? color.green : color.red)
    buy = close > leadLine1[26] and close > leadLine2[26]
    sell = close < leadLine1[26] and close < leadLine2[26]


    if(buy and inTradeWindow)
        strategy.entry("Buy", strategy.long, when = buy)

    if(sell and inTradeWindow)
        strategy.entry("Sell", strategy.short, when = sell)

strategy(title="Ichimoku Cloud", shorttitle="Ichimoku", overlay=true, commission_type=strategy.commission.percent,commission_value=0.075, initial_capital = 1000,  default_qty_type=strategy.percent_of_equity, default_qty_value=100)

//print(strategy.netprofit)
//temp_year = input(2019)
//temp_month = input(1)


// for i = 1 to 16 
s_year = input(2022)
s_month = input(8)
s_day = input(1)
s_moment = timestamp(s_year,s_month,s_day) 


e_year = input(2022)
e_month = input(11)
e_day = input(1)
e_moment = timestamp(e_year,e_month,e_day) 


inTradeWindow = (time > s_moment and time < e_moment)
ichimoku_function(inTradeWindow)
